<?php
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));
    $result = $mysqli->query("SELECT *FROM client") or die($mysqli->error);
    $update = false;
    $numClient = "";
    $nom = "";
    

      //Ajouter
        if(isset($_POST['save']))
        {
            $numClient = $_POST['numClient'];
            $nom = $_POST['nom'];
            

            $mysqli->query("INSERT INTO client VALUES ('$numClient','$nom')") or
            die($mysqli->error);

            $_SESSION['message'] = "";
            $_SESSION['msg_type'] = "success";

            header("location: ajout_client.php");
        }
        
        //Effacer
        if(isset($_GET['deleteClient']))
        {
            $numClient = $_GET['deleteClient'];
            $mysqli->query("DELETE FROM client WHERE numClient='$numClient'") or die($mysqli->error);
            $_SESSION['message'] = "";
            $_SESSION['msg_type'] = "danger";

            header("location: ajout_client.php");
        }

        //Modifier
        if(isset($_GET['editClient']))
        {
            $numClient = $_GET['editClient'];
            $update = true; 
            $result = $mysqli->query("SELECT *FROM client where numClient='$numClient' ") or die($mysqli->error);

            if(count($result)==1)
            {
                $row = $result->fetch_array();
                $nom = $row['nom'];
            }
        }

        if(isset($_POST['update']))
        {
            $numClient = $_POST['numClient'];
            $num_cli =  $_POST['numclients'];
            $nom = $_POST['nom'];

            $mysqli->query("UPDATE client set numClient='$numClient', nom='$nom' where numClient='$num_cli' ") or die($mysqli->error);

            $_SESSION['message'] = "";
            $_SESSION['msg_type'] = "warning";
            
            header("location: ajout_client.php");
        }

?>