<?php
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));
    $result = $mysqli->query("SELECT *FROM vente") or die($mysqli->error);
    $result1 = $mysqli->query("SELECT *FROM client") or die($mysqli->error);
    $result2 = $mysqli->query("SELECT *FROM voiture") or die($mysqli->error);

    $update = false;
    $numClient="";
    $numVoiture = "";
    $qte = "";
    $date = "";
    

      //Ajouter
        if(isset($_POST['save']))
        {
            $numClient=$_POST['numClient'];
            $numVoiture = $_POST['numVoiture'];
            $qte = $_POST['qte'];
            $date = $_POST['date'];

            $mysqli->query("INSERT INTO vente VALUES ('$numClient', '$numVoiture', '$qte', '$date' )") or die($mysqli->error);
            $mysqli->query("UPDATE voiture INNER JOIN vente ON vente.numVoiture = voiture.numVoiture  SET stock = stock - qte WHERE vente.numVoiture = '$numVoiture'  AND  vente.numClient = '$numClient' ");

            $_SESSION['message'] = "Record has been saved";
            $_SESSION['msg_type'] = "success";

            header("location: ajout_vente.php");
        } 


        //Effacer
        if(isset($_GET['deleteClient'],$_GET['deleteVoiture'],$_GET['deleteDate']))
        {
            $numClient = $_GET['deleteClient'];
            $numVoiture = $_GET['deleteVoiture'];
            $date = $_GET['deleteDate'];

            $mysqli->query("UPDATE voiture INNER JOIN vente ON vente.numVoiture = voiture.numVoiture  SET stock = stock + qte WHERE vente.numVoiture = '$numVoiture'  AND  vente.numClient = '$numClient' ");
            $mysqli->query("DELETE FROM vente WHERE numClient='$numClient' and numVoiture='$numVoiture' and Date_vente='$date' ") or die($mysqli->error);
            
            
            
            $_SESSION['message'] = "Record has been delete";
            $_SESSION['msg_type'] = "danger";

            header("location: ajout_vente.php");
        }

        //Modifier
        if(isset($_GET['editClient'],$_GET['editVoiture'],$_GET['editDate']))
        {
            $numClient = $_GET['editClient'];
            $numVoiture = $_GET['editVoiture'];
            $date = $_GET['editDate'];
            $update = true; 

            $result = $mysqli->query("SELECT *FROM vente where numClient='$numClient' and numVoiture='$numVoiture' and Date_vente='$date' ") or die($mysqli->error);

            if(count($result)==1)
            {
                $row = $result->fetch_array();
                $qte = $row['Qte'];
            }
        }

        if(isset($_POST['update']))
        {
            $num_Client = $_POST['num_Client'];
            $num_Voiture = $_POST['num_Voiture'];
            $date_vente = $_POST['date_vente'];

            $numClient= $_POST['numClient'];
            $numVoiture = $_POST['numVoiture'];
            $qte = $_POST['qte'];
            $date = $_POST['date'];

            //Modification de stock
            $mysqli->query("UPDATE voiture INNER JOIN vente ON vente.numVoiture = voiture.numVoiture  SET stock = (stock + (qte - $qte)) WHERE vente.numVoiture = '$numVoiture'  AND  vente.numClient = '$numClient' ");
            //Modification de table
            $mysqli->query("UPDATE vente set numClient='$numClient', numVoiture='$numVoiture', Qte='$qte', Date_vente='$date' where numClient='$num_Client' and numVoiture='$num_Voiture' and date_vente='$date_vente' ") or die($mysqli->error);

            $_SESSION['message'] = "Record has been update";
            $_SESSION['msg_type'] = "waring";
            
            header("location: ajout_vente.php");
        }
?>