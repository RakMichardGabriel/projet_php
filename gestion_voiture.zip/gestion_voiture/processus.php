<?php
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));

        if(isset($_POST['search']))
        {
            $mot_cle = $_POST['barre'];
            $result = $mysqli->query("SELECT *FROM client where CONCAT(numClient,nom) LIKE '%".$mot_cle."%'") or die($mysqli->error);
            $result1 = $mysqli->query("SELECT *FROM voiture where CONCAT(numVoiture,marque) LIKE '%".$mot_cle."%'") or die($mysqli->error);
            
            $_SESSION['message'] = "";
            $_SESSION['msg_type'] = "Alerte";
        }
        else {
            $result = $mysqli->query("SELECT *FROM client");
            $result1 = $mysqli->query("SELECT *FROM voiture");

        }


    
?>
    