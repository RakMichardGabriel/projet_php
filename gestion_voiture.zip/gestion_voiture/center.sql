-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  sam. 13 fév. 2021 à 23:29
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `data_center`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `numClient` varchar(4) NOT NULL,
  `nom` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`numClient`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`numClient`, `nom`) VALUES
('C8', 'Mahafaly'),
('C3', 'Aldo'),
('C18', 'Client'),
('C17', 'Voiture');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `email` varchar(20) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(15) NOT NULL,
  `user_name` varchar(15) NOT NULL,
  `password` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `nom`, `prenom`, `user_name`, `password`) VALUES
(1, 'aldo@gmail.com', '', '', '', 'A000joker'),
(4, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `vente`
--

DROP TABLE IF EXISTS `vente`;
CREATE TABLE IF NOT EXISTS `vente` (
  `numClient` varchar(4) NOT NULL,
  `numVoiture` varchar(8) NOT NULL,
  `Qte` int(11) DEFAULT NULL,
  `Date_vente` date NOT NULL,
  PRIMARY KEY (`numClient`,`numVoiture`,`Date_vente`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `vente`
--

INSERT INTO `vente` (`numClient`, `numVoiture`, `Qte`, `Date_vente`) VALUES
('C3', 'V07', 6, '2021-02-20'),
('C3', 'V09', 3, '2021-02-14'),
('C18', 'V03', 2, '2021-02-10'),
('C3', 'V09', 8, '2021-02-11'),
('C8', 'V09', 3, '2021-02-04');

-- --------------------------------------------------------

--
-- Structure de la table `voiture`
--

DROP TABLE IF EXISTS `voiture`;
CREATE TABLE IF NOT EXISTS `voiture` (
  `numVoiture` varchar(8) NOT NULL,
  `Marque` varchar(20) DEFAULT NULL,
  `PU` double(11,2) NOT NULL,
  `Stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`numVoiture`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `voiture`
--

INSERT INTO `voiture` (`numVoiture`, `Marque`, `PU`, `Stock`) VALUES
('V03', 'Anta', 2000.00, 5),
('V09', 'Jordan', 3000.00, 9),
('V07', 'Adidas', 3500.00, 3);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
