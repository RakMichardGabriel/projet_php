<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>Liste de vente</title>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-light navbar-light">
            
            <a class="navbar-brand" href="#">BuyCar</a>
            
            <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="accueil.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="ajout_voiture.php">Voiture</a></li>
            <li class="nav-item"><a class="nav-link" href="ajout_client.php">Client</a></li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Vente</a>
                <div class="dropdown-menu">
                <a class="dropdown-item active" href="ajout_vente.php">Liste de vente</a>
                <a class="dropdown-item" href="facture.php">Facture de client</a>
                <a class="dropdown-item" href="liste_vente.php">Liste de voiture vendue</a>                        
                <a class="dropdown-item" href="chiffre.php">Chiffre d'affaire</a>
                </div>
            </li>
            <li class="nav-item">
                <form class="form-inline" action="barre_recherche.php" method="Post">

                <input class="form-control mr-sm-1" type="text" name="barre" placeholder ="Recherche">
                <button class="btn btn-success" type="submit" name="search" id="rechercher">Rechercher</button>

                </form>
            </li>
            </ul>
        
    </nav>

        
    

    <br>
    <?php 
        include 'inserer3.php'; 
        include 'session.php';
    ?>

       

    <div class="container-fluid">
            <table class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>NumClient</th>
                        <th>NumVoiture</th>
                        <th>Quantité</th>
                        <th>Date de vente</th>
                        <th></th>
                    </tr>
                </thead>
            <?php
                while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['numClient']; ?></td>
                        <td><?php echo $row['numVoiture']; ?></td>
                        <td><?php echo $row['Qte']; ?></td>
                        <td><?php echo $row['Date_vente']; ?></td>
                        
                        <td>
                            <button class="btn btn-default"><a href="ajout_vente.php?editClient=<?php echo $row['numClient']; ?>&editVoiture=<?php echo $row['numVoiture']; ?>&editDate=<?php echo $row['Date_vente']; ?>">Modifier</a></button>
                            <button class="btn btn-default"><a href="inserer3.php?deleteClient=<?php echo $row['numClient']; ?>&deleteVoiture=<?php echo $row['numVoiture']; ?>&deleteDate=<?php echo $row['Date_vente']; ?>">Effacer</a></button>
                        </td>
                    </tr>
                <?php endwhile; ?> 

            </table>
        </div>
    </div>

    <div class="container">
        <form  method="post" action="inserer3.php">

            <!-- Indicateur du ligne à modifier -->
            <input style="" type="hidden" name="num_Client" value="<?php echo $numClient; ?>">
            <input type="hidden" name="num_Voiture" value="<?php echo $numVoiture; ?>">
            <input type="hidden" name="date_vente" value="<?php echo $date; ?>">
            
            <div class="form-group">
            <label> N° Client :</label><br>
                <input list="liste_client" name="numClient" value="<?php echo $numClient; ?>" ><br><br>
                <datalist id="liste_client">
                    <?php while($numC = $result1->fetch_array()): ?>
                        <option value="<?php echo $numC['numClient']; ?>">
                    <?php endwhile; ?>
                </datalist>
            </div>

            <div class="form-group">
                <label> N° Voiture :</label><br>
                <input list="liste_voiture" name="numVoiture" value="<?php echo $numVoiture; ?>" ><br><br>
                <datalist id="liste_voiture">
                    <?php while($numV = $result2->fetch_array()): ?>
                        <option value="<?php echo $numV['numVoiture']; ?>">
                    <?php endwhile; ?>
                </datalist>
            </div> 

            <div class="form-group">   
                <label for="qte">Quantite :</label><br>
                <input type="number" name="qte" value="<?php echo $qte; ?>" placeholder="Quantite"><br><br>
            </div>

            <div class="form-group">
                <label for="date">Date :</label><br>
                <input type="date" name="date" value="<?php echo $date; ?>" placeholder="Date de vente"><br><br>
            </div>

            <?php
                if($update == true):
            ?>
            <button type="submit" class="btn btn-success" name="update" >Modifier</button>
            <?php else: ?>
            <button type="submit" class="btn btn-primary" name="save">Ajouter</button>
            <?php endif; ?>
        </form>
    </div>
    
</body>
</html>