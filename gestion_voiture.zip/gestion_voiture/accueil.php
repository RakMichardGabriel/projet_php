<!DOCTYPE html>
<html>
<head>    
    <?php 
      include 'processus.php'; 
      include 'session.php';
    ?>

    <script src="jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>Gestion de vente de voitures</title>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-light navbar-light">
        
            <a class="navbar-brand" href="#">BuyCar</a>
            
            <ul class="navbar-nav">
              <li class="nav-item active"><a class="nav-link" href="accueil.php">Home</a></li>
              <li class="nav-item"><a class="nav-link" href="ajout_voiture.php">Voiture</a></li>
              <li class="nav-item"><a class="nav-link" href="ajout_client.php">Client</a></li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Vente</a>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="ajout_vente.php">Liste de vente</a>
                  <a class="dropdown-item" href="facture.php">Facture de client</a>
                  <a class="dropdown-item" href="liste_vente.php">Liste de voiture vendue</a>                        
                  <a class="dropdown-item" href="chiffre.php">Chiffre d'affaire</a>
                </div>
              </li>
            </ul> 
                
            <form class="form-inline navbar-left" action="barre_recherche.php" method="Post">

              <input class="form-control mr-sm-1" type="text" name="barre" placeholder ="Recherche">
              <button class="btn btn-success" type="submit" name="search" id="rechercher">Rechercher</button>

            </form>
                
              
            
        
    </nav>



</body>
</html>