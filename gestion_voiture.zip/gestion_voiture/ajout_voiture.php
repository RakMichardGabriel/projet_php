<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>Voitures</title>
</head>
<body>
    
    <nav class="navbar navbar-expand-sm bg-light navbar-light">
            
                <a class="navbar-brand" href="#">BuyCar</a>
                
                <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="accueil.php">Home</a></li>
                <li class="nav-item active"><a class="nav-link" href="ajout_voiture.php">Voiture</a></li>
                <li class="nav-item"><a class="nav-link" href="ajout_client.php">Client</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Vente</a>
                    <div class="dropdown-menu">
                    <a class="dropdown-item" href="ajout_vente.php">Liste de vente</a>
                    <a class="dropdown-item" href="facture.php">Facture de client</a>
                    <a class="dropdown-item" href="liste_vente.php">Liste de voiture vendue</a>                        
                    <a class="dropdown-item" href="chiffre.php">Chiffre d'affaire</a>
                    </div>
                </li>
                <li class="nav-item">
                    <form class="form-inline" action="barre_recherche.php" method="Post">

                    <input class="form-control mr-sm-1" type="text" name="barre" placeholder ="Recherche">
                    <button class="btn btn-success" type="submit" name="search" id="rechercher">Rechercher</button>

                    </form>
                </li>
                </ul>
            
    </nav>
    <br>
    
    <?php 
        include 'inserer1.php'; 
        include 'session.php';
    ?>

    
        
        
        <div class="container-fluid">
            <table  class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>N° Voiture</th>
                        <th>Marque</th>
                        <th>Prix Unitaire</th>
                        <th>Stock</th>
                        <th></th>
                    </tr>
                </thead>
            <?php
                while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['numVoiture']; ?></td>
                        <td><?php echo $row['Marque']; ?></td>
                        <td><?php echo $row['PU']; ?></td>
                        <td><?php echo $row['Stock']; ?></td>
                        <td>
                        <button class="btn btn-default"><a href="ajout_voiture.php?editVoiture=<?php echo $row['numVoiture']; ?>">Modifier</a></button>
                        <button class="btn btn-default"><a href="ajout_voiture.php?deleteVoiture=<?php echo $row['numVoiture']; ?>">Effacer</a></button>
                        </td>

                        
                    </tr>
                <?php endwhile; ?> 

            </table>
        </div>
    
    <div class="container">
        <form  method="post" action="inserer1.php">
            <input type="hidden" name="numVoitures" value="<?php echo $numVoiture; ?>">
            
            <div class="form-group" >
            <label for="numVoiture" >Numero de voiture :</label>
            <input class="form-control" type="text" name="numVoiture" value="<?php echo $numVoiture; ?>" placeholder="Numero de voiture">
            </div>
            
            <div class="form-group">
            <label for="marque">Marque :</label>
            <input class="form-control" type="text" name="marque" value="<?php echo $marque; ?>" placeholder="Marque">
            </div>
            
            <div class="form-group">
            <label for="PU">Prix unitaire :</label>
            <input class="form-control" type="price" name="PU" value="<?php echo $PU; ?>" placeholder="Prix unit...">
            </div>
            
            <div class="form-group">
            <label for="emal">Stock :</label>
            <input class="form-control" type="number" name="stock" value="<?php echo $stock; ?>" placeholder="Nombre de stock">
            </div>
            
        <div class="form-group">
            <?php
                if($update == true):
            ?>
            <button class="btn btn-success" type="submit" name="update">Modifier</button>
            <?php else: ?>
            <button class="btn btn-info" type="submit" name="save">Ajouter</button>
            <?php endif; ?>
        </div>
        </form>
    </div>
    

</body>
</html>