<?php 

$nom = $_POST['Nom'];
$mdp=  $_POST['mdp'];
$tableau=[
  'Nom' => $nom, 'mdp' => $mdp
];

try{
  $con=new PDO('mysql:host=localhost;dbname=center',$nom, $mdp);
}
catch (Exception $e)
{ 
  die('Erreur : ' . $e->getMessage());
  header('Location:login.php');
}

setcookie('login',serialize($tableau));
header('Location:accueil.php');

?>