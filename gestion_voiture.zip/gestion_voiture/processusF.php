<?php
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));
    
    

        if(isset($_POST['valider']))
        {
            $numClient = $_POST['numClient'];
            $date= $_POST['date'];

            $result3 = $mysqli->query("SELECT nom as Nom, voiture.numVoiture, marque as Marque, PU as PU, qte as Qte, PU*qte as Montant FROM voiture, vente, client  where (vente.numVoiture=voiture.numVoiture) and (vente.numClient=client.numClient) and client.numClient='$numClient' and date_vente ='$date'") or die($mysqli->error);

            $result4 = $mysqli->query("SELECT sum(PU*Qte) as Total FROM vente, voiture where (vente.numVoiture=voiture.numVoiture) and vente.numClient='$numClient' and date_vente='$date' ") or die($mysqli->error);
            $result = $mysqli->query("SELECT nom FROM vente, client where (vente.numClient=client.numClient) and client.numClient='$numClient' ") or die($mysqli->error);


            $_SESSION['message'] = "OK";
            $_SESSION['msg_type'] = "Alerte";
        }
        


    
?>