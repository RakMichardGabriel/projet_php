<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>Liste de voiture vendue</title>
</head>
<body>
    <nav class="navbar navbar-expand-sm bg-light navbar-light">
            
            <a class="navbar-brand" href="#">BuyCar</a>
            
            <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="accueil.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="ajout_voiture.php">Voiture</a></li>
            <li class="nav-item"><a class="nav-link" href="ajout_client.php">Client</a></li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Vente</a>
                <div class="dropdown-menu">
                <a class="dropdown-item" href="ajout_vente.php">Liste de vente</a>
                <a class="dropdown-item" href="facture.php">Facture de client</a>
                <a class="dropdown-item active" href="liste_vente.php">Liste de voiture vendue</a>                        
                <a class="dropdown-item" href="chiffre.php">Chiffre d'affaire</a>
                </div>
            </li>
            <li class="nav-item"><a class="nav-link" href="barre_recherche.php">Rechercher</a></li>
            </ul>
        
    </nav>
    <br>

<?php 
    include 'processus1.php'; 
    include 'session.php';
    ?>
    
    <div class="container">
        <form action="liste_vente.php" method="Post">
            <label >Veuillez saisir la premiere date :</label><br>
            <input type="date" name="date1" placeholder ="Debut de date"><br><br>
            <label >Veuillez saisir la seconde date :</label><br>
            <input type="date" name="date2" placeholder ="Fin de date"><br><br>

            <input type="submit" name="search" value="Rechercher" class="btn btn-info"><br><br>

            <table class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th>N° Voiture</th>
                        <th>Marque</th>
                    </tr>
                </thead>
                <?php
                    while($row3 = $result3->fetch_array()): ?>
                    <tr>
                        <td><?php echo $row3['numVoiture']; ?></td>
                        <td><?php echo $row3['Marque']; ?></td>     
                    </tr>
                <?php endwhile; ?>         
            </table>
        </form>
    </div>
    
</body>
</html>