<?php
    
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));
    $result = $mysqli->query("SELECT *FROM voiture") or die($mysqli->error);

    $update = false;
    $numVoiture = "";
    $marque = "";
    $PU = "";
    $stock = "";

      //Ajouter
        if(isset($_POST['save']))
        {
            $numVoiture = $_POST['numVoiture'];
            $marque = $_POST['marque'];
            $PU = $_POST['PU'];
            $stock = $_POST['stock'];

            $mysqli->query("INSERT INTO voiture VALUES ('$numVoiture','$marque', '$PU', '$stock')") or die($mysqli->error);

            $_SESSION['message'] = "Record has been saved";
            $_SESSION['msg_type'] = "success";

            header("location: ajout_voiture.php");
        } 
        
        
        //Effacer
        if(isset($_GET['deleteVoiture']))
        {
            $numVoiture = $_GET['deleteVoiture'];
            $mysqli->query("DELETE FROM voiture WHERE numVoiture='$numVoiture'") or die($mysqli->error);

            $_SESSION['message'] = "Record has been delete";
            $_SESSION['msg_type'] = "danger";

            header("location: ajout_voiture.php");
        }

        //Modifier
        if(isset($_GET['editVoiture']))
        {
            $numVoiture = $_GET['editVoiture'];
            $update = true; 
            $result = $mysqli->query("SELECT *FROM voiture where numVoiture='$numVoiture' ") or die($mysqli->error);

            if(count($result)==1)
            {
                $row = $result->fetch_array();
                $marque = $row['Marque'];
                $PU = $row['PU'];
                $stock = $row['Stock'];
            }
        }

        if(isset($_POST['update']))
        {
            $numVoiture = $_POST['numVoiture'];
            $num_voit =  $_POST['numVoitures'];
            $marque = $_POST['marque'];
            $PU = $_POST['PU'];
            $stock = $_POST['stock'];

            $mysqli->query("UPDATE voiture set numVoiture='$numVoiture', Marque='$marque', PU='$PU', Stock='$stock' where numVoiture='$num_voit' ") or die($mysqli->error);

            $_SESSION['message'] = "Record has been update";
            $_SESSION['msg_type'] = "waring";
            
            header("location: ajout_voiture.php");
        }

    
    
    
