<?php
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));
    $numClient ="";
    $nom ="";

        if(isset($_POST['search']))
        {
            $date1 = $_POST['date1'];
            $date2 = $_POST['date2'];
            $result3 = $mysqli->query("SELECT voiture.numVoiture, marque as Marque FROM voiture, vente  where (vente.numVoiture=voiture.numVoiture) and (date_vente BETWEEN '$date1' and '$date2')") or die($mysqli->error);
            
            $_SESSION['message'] = "Resultat trouveé ...";
            $_SESSION['msg_type'] = "Alerte";
        }
        else {
            $result3 = $mysqli->query("SELECT voiture.numVoiture, marque as Marque FROM  voiture, vente where vente.numVoiture=voiture.numVoiture") or die($mysqli->error);

        }
        
        if(isset($_POST['valider']))
        {
            $numClient = $_POST['numClient'];   
            $result3 = $mysqli->query("SELECT nom as Nom, voiture.numVoiture, marque as Marque, PU as PU, qte as Qte, PU*qte as Montant FROM voiture, vente, client  where (vente.numVoiture=voiture.numVoiture) and (vente.numClient=client.numClient) and client.numClient='$numClient'") or die($mysqli->error);
        
            $_SESSION['message'] = "Facture du client ...";
            $_SESSION['msg_type'] = "Alerte";
        }
        
        if(isset($_POST['valider']))
        {
            $numClient = $_POST['numClient'];   
            $result4 = $mysqli->query("SELECT nom as Nom, voiture.numVoiture, marque as Marque, PU as PU, qte as Qte, PU*qte as Montant FROM voiture, vente, client  where (vente.numVoiture=voiture.numVoiture) and (vente.numClient=client.numClient) and client.numClient='$numClient'") or die($mysqli->error);
            
            $cli = $result4->fetch_array();
            $nom = $cli['Nom'];

            
        }

    
?>
    