<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>Facture du client</title>
</head>
<body>

    <nav class="navbar navbar-expand-sm bg-light navbar-light">
            
            <a class="navbar-brand" href="#">BuyCar</a>
            
            <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="accueil.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="ajout_voiture.php">Voiture</a></li>
            <li class="nav-item"><a class="nav-link" href="ajout_client.php">Client</a></li>
            <li class="nav-item dropdown active">
                <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">Vente</a>
                <div class="dropdown-menu">
                <a class="dropdown-item" href="ajout_vente.php">Liste de vente</a>
                <a class="dropdown-item active" href="facture.php">Facture de client</a>
                <a class="dropdown-item" href="liste_vente.php">Liste de voiture vendue</a>                        
                <a class="dropdown-item" href="chiffre.php">Chiffre d'affaire</a>
                </div>
            </li>
            <li class="nav-item">
                <form class="form-inline" action="barre_recherche.php" method="Post">

                <input class="form-control mr-sm-1" type="text" name="barre" placeholder ="Recherche">
                <button class="btn btn-success" type="submit" name="search" id="rechercher">Rechercher</button>

                </form>
            </li>
            </ul>
        
    </nav>

    <br>


    <?php 
        include 'processusF.php'; 
        include 'session.php';
        $total = 0;
        $nom ="";
    ?>
        
        <div class="container">
            <form action="facture.php" method="Post">

                <div class="form-inline ">
                    <!-- Identité du client sur le facture -->
                    <label class="mr-sm-2">N° du Client:</label><br>
                    <input class="form-control mr-sm-2" type="text" name="numClient" placeholder ="NumClient"><br>
                    <label class="mr-sm-2">Date de vente:</label><br>
                    <input class="form-control mr-sm-2" type="date" name="date" placeholder ="Date de facture"><br>
                    <input type="submit" class="btn btn-info" name="valider" value="Valider"><br><br>
                </div>
                <div>
                <p>Date : <?php if(isset($_POST['valider'])){
                                                                     
                                    echo $date;
                                    }                
                            ?>
                            
             </p> 
                    <p>Nom : <?php if(isset($_POST['valider'])){
                                    $row5 = $result->fetch_assoc();
                                    $nom = $row5['nom'];
                                    echo $nom;
                                    }                
                            ?>
                            
             </p> 
                </div>

                <table class="table table-bordered"">
                    <thead class="thead-light">
                        <tr>
                            <th>Numero Voiture</th>
                            <th>Marque</th>
                            <th>PU</th>
                            <th>Quantité</th>
                            <th>Montant</th>
                        </tr>
                    </thead>
                    <?php
                     if (isset($_POST['valider'])):?>
                        <?php $total = 0;
                              $montant = 0;
                        ?>
                        <?php while($row = $result3->fetch_array()): ?>
                            <tr>
                                <td><?php echo $row['numVoiture']; ?></td>
                                <td><?php echo $row['Marque']; ?></td>
                                <td><?php echo $row['PU']; ?></td>
                                <td><?php echo $row['Qte']; ?></td>
                                <td><?php echo $row['Montant']; ?></td>     
                            </tr>
                        <?php endwhile; ?>
                    <?php  endif; ?>
                </table>      
                <div>
                    <p>Total: <?php if(isset($_POST['valider']))
                            {
                            $row4 = $result4->fetch_array();
                            $total = $row4['Total'];
                            echo $total;
                            } ?>
                    </p> 
                </div>
    </body>
</html>