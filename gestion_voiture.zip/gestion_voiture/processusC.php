<?php
    session_start();

    $mysqli = new mysqli('localhost', 'root', '','center') or die(mysqli_error($mysqli));
    
    

        if(isset($_POST['valider']))
        {
            $date= $_POST['annee'];

           
            $result4 = $mysqli->query("SELECT vente.numClient, nom, sum(PU*Qte) as Total FROM client, voiture, vente where (vente.numVoiture=voiture.numVoiture) and (vente.numClient=client.numClient) and year(date_vente)='$date' group by vente.numClient") or die($mysqli->error);
            

            $_SESSION['message'] = "OK";
            $_SESSION['msg_type'] = "Alerte";
        }
        


    
?>