<?php
function auth(){
  if(empty($_COOKIE['login'])){
    header('Location: login.php');
  }
  else{
    $connex= unserialize($_COOKIE ['login']);
    try{
      $con=new PDO('mysql:host=localhost;dbname=center',$connex['Nom'], $connex['mdp']);
       }
    catch (Exception $e)
    { 
      die('Erreur : ' . $e->getMessage());
    }
    catch (PDOException $e) {
        echo 'Connexion échouée : ' . $e->getMessage();
                            }
     }
     return $con;
}



?>
